import tkinter as tk
from tkinter import font

class ModernCalculator(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Dynamic Modern Calculator")
        self.geometry("360x500")
        self.resizable(False, False)
        self.configure(bg="#121417")

        self.expression = ""

        # Custom fonts
        self.display_font = font.Font(family="Segoe UI", size=28, weight="bold")
        self.button_font = font.Font(family="Segoe UI", size=18, weight="bold")
        self.title_font = font.Font(family="Segoe UI", size=28, weight="bold")

        self._create_title()
        self._create_display()
        self._create_buttons()
        self._bind_keys()

    def _create_title(self):
        title = tk.Label(
            self,
            text="Calculator",
            bg="#121417",
            fg="#61dafb",
            font=self.title_font,
            pady=12
        )
        title.pack()

    def _create_display(self):
        self.display_var = tk.StringVar()
        self.display = tk.Entry(
            self,
            textvariable=self.display_var,
            font=self.display_font,
            bg="#1c1f26",
            fg="#e6e6e6",
            borderwidth=0,
            justify="right",
            relief="flat",
            insertbackground="#e6e6e6",
            highlightthickness=2,
            highlightbackground="#282c34"
        )
        self.display.pack(fill="x", padx=20, pady=(0, 15), ipady=18)
        self.display_var.set("0")

    def _create_buttons(self):
        # Layout with "=" spanning full width on last row
        button_layout = [
            ["7", "8", "9", "/"],
            ["4", "5", "6", "*"],
            ["1", "2", "3", "-"],
            ["C", "0", ".", "+"],
            ["="],
        ]

        btn_frame = tk.Frame(self, bg="#121417")
        btn_frame.pack(expand=True, fill="both", padx=20, pady=10)

        for r, row in enumerate(button_layout):
            row_frame = tk.Frame(btn_frame, bg="#121417")
            row_frame.pack(expand=True, fill="both")
            if r == 4:  # "=" button row
                btn = self._create_button(row[0], row_frame)
                # Make "=" button span full width
                btn.pack(side="left", expand=True, fill="both", padx=5, pady=5)
            else:
                for c, char in enumerate(row):
                    btn = self._create_button(char, row_frame)
                    btn.pack(side="left", expand=True, fill="both", padx=5, pady=5)

    def _create_button(self, char, parent):
        colors = {
            "bg": "#2d313d",
            "fg": "#abb2bf",
            "activebg": "#61dafb",
            "activefg": "#121417",
        }
        if char == "C":
            colors["bg"] = "#e06c75"
            colors["activebg"] = "#be5046"
        if char == "=":
            colors["bg"] = "#98c379"
            colors["activebg"] = "#7eb475"

        btn = tk.Button(
            parent,
            text=char,
            font=self.button_font,
            fg=colors["fg"],
            bg=colors["bg"],
            activebackground=colors["activebg"],
            activeforeground=colors["activefg"],
            borderwidth=0,
            relief="ridge",
            padx=10,
            pady=10,
            command=lambda ch=char: self.on_button_click(ch),
            cursor="hand2",
        )
        # Rounded corners mimic using padding and flat relief
        btn.configure(highlightthickness=0, bd=0)

        # Hover effects
        btn.bind("<Enter>", lambda e, b=btn, c=colors["activebg"]: b.config(bg=c))
        btn.bind("<Leave>", lambda e, b=btn, c=colors["bg"]: b.config(bg=c))

        return btn

    def on_button_click(self, char):
        if char == "C":
            self.expression = ""
            self.display_var.set("0")
        elif char == "=":
            self._calculate_result()
        else:
            if self.expression == "" and char in "/*+-":
                # Prevent expression from starting with an operator except minus for negative
                if char != "-":
                    return
            # Limit length to avoid overflow
            if len(self.expression) > 30:
                return
            self.expression += char
            self.display_var.set(self.expression)

    def _calculate_result(self):
        try:
            expr = self.expression.replace("÷", "/")
            result = eval(expr)
            if isinstance(result, float) and result.is_integer():
                result = int(result)
            self.expression = str(result)
            self.display_var.set(self.expression)
        except Exception:
            self._show_error()

    def _show_error(self):
        self.display_var.set("Error")
        self.expression = ""
        # After short delay reset display
        self.after(1500, lambda: self.display_var.set("0"))

    def _bind_keys(self):
        self.bind("<Return>", lambda e: self.on_button_click("="))
        self.bind("<BackSpace>", self._handle_backspace)
        valid_keys = "0123456789.+-*/"
        for key in valid_keys:
            self.bind(key, self._handle_keypress)

    def _handle_keypress(self, event):
        self.on_button_click(event.char)

    def _handle_backspace(self, event):
        if self.expression:
            self.expression = self.expression[:-1]
            self.display_var.set(self.expression if self.expression else "0")

if __name__ == "__main__":
    app = ModernCalculator()
    app.mainloop()

